import 'dart:io';
import 'dart:math';
import 'package:image/image.dart' as img;

class ImageAnalysisService {

  /// Automatically detect strip region and return average RGB
  Future<List<double>> getAverageRGB(String path) async {
    final bytes = File(path).readAsBytesSync();
    final image = img.decodeImage(bytes)!;

    int minX = image.width, minY = image.height;
    int maxX = 0, maxY = 0;

    // Simple detection: look for non-background pixels
    for (int x = 0; x < image.width; x++) {
      for (int y = 0; y < image.height; y++) {
        final pixel = image.getPixel(x, y);
        num r = pixel.r;
        num g = pixel.g;
        num b = pixel.b;

        // Detect colored pixels (strip), adjust threshold if needed
        if ((r + g + b) > 100) { // exclude very dark background
          if (x < minX) minX = x;
          if (y < minY) minY = y;
          if (x > maxX) maxX = x;
          if (y > maxY) maxY = y;
        }
      }
    }

    // Safety check
    if (minX >= maxX || minY >= maxY) {
      // fallback to whole image
      minX = 0; minY = 0;
      maxX = image.width;
      maxY = image.height;
    }

    // Average RGB in detected region
    double rSum = 0, gSum = 0, bSum = 0;
    int count = 0;

    for (int x = minX; x <= maxX; x++) {
      for (int y = minY; y <= maxY; y++) {
        final pixel = image.getPixel(x, y);
        rSum += pixel.r;
        gSum += pixel.g;
        bSum += pixel.b;
        count++;
      }
    }

    double r = rSum / count;
    double g = gSum / count;
    double b = bSum / count;

    // Simple white balance
    double sum = r + g + b;
    if (sum > 0) {
      r = (r / sum) * 255;
      g = (g / sum) * 255;
      b = (b / sum) * 255;
    }

    return [r, g, b];
  }

  double colorDistance(List<double> a, List<double> b) {
    return sqrt(
      pow(a[0] - b[0], 2) +
          pow(a[1] - b[1], 2) +
          pow(a[2] - b[2], 2),
    );
  }

  String matchLevel(List<double> sampleRGB, Map<String, List<double>> levels,
      {double threshold = 50}) {
    double minDist = double.infinity;
    String best = "UNKNOWN";

    levels.forEach((level, rgb) {
      double d = colorDistance(sampleRGB, rgb);
      if (d < minDist) {
        minDist = d;
        best = level;
      }
    });

    if (minDist > threshold) {
      return "UNKNOWN";
    }

    return best;
  }
}