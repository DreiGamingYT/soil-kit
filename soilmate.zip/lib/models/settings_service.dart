import 'package:flutter/material.dart';

/// App-wide settings singleton using ValueNotifiers so UI rebuilds reactively.
class SettingsService {
  SettingsService._();
  static final SettingsService instance = SettingsService._();

  // Display
  final ValueNotifier<ThemeMode> themeMode = ValueNotifier(ThemeMode.light);
  final ValueNotifier<String> measurementUnit = ValueNotifier('mg/kg');
  final ValueNotifier<String> language = ValueNotifier('English');

  // Camera
  final ValueNotifier<bool> autoAnalyze = ValueNotifier(true);
  final ValueNotifier<bool> autoSavePhotos = ValueNotifier(false);

  // Notifications
  final ValueNotifier<bool> notificationsEnabled = ValueNotifier(true);
  final ValueNotifier<bool> notificationPermissionGranted = ValueNotifier(false);

  bool get isDark => themeMode.value == ThemeMode.dark;

  void toggleDarkMode(bool on) {
    themeMode.value = on ? ThemeMode.dark : ThemeMode.light;
  }
}
