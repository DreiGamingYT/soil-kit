import 'package:flutter/material.dart';
import '../models/soil_data_service.dart';
import '../widgets/bottom_nav.dart';
import 'camera_result_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _svc = SoilDataService.instance;

  String _month(int m) => const ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][m-1];

  Color _scoreColor(double s) {
    if (s >= 70) return const Color(0xFF43A047);
    if (s >= 45) return Colors.orange;
    return Colors.red;
  }

  void _confirmDelete(int index) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Delete Result'),
      content: const Text('Remove this soil test from history?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          onPressed: () {
            setState(() => _svc.removeResult(index));
            Navigator.pop(context);
          },
          child: const Text('Delete', style: TextStyle(color: Colors.white)),
        ),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final items = _svc.results;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('History', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22)),
        backgroundColor: Colors.white, elevation: 0, foregroundColor: Colors.black,
        centerTitle: true, automaticallyImplyLeading: false,
      ),
      body: items.isEmpty
        ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.history, size: 72, color: Colors.grey[300]),
            const SizedBox(height: 12),
            const Text('No results yet', style: TextStyle(color: Colors.grey, fontSize: 15)),
            const SizedBox(height: 6),
            const Text('Analyze a soil sample to see history here', style: TextStyle(color: Colors.grey, fontSize: 12)),
          ]))
        : ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            itemCount: items.length,
            itemBuilder: (context, i) {
              final item = items[i];
              final dateStr = '${_month(item.date.month)} ${item.date.day}, ${item.date.year}';
              final col = _scoreColor(item.overallScore);
              return Dismissible(
                key: Key('hist_$i${item.date}'),
                direction: DismissDirection.endToStart,
                background: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(12)),
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  child: const Icon(Icons.delete_outline, color: Colors.white),
                ),
                confirmDismiss: (_) async {
                  _confirmDelete(i);
                  return false;
                },
                child: Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                  elevation: 0,
                  child: ListTile(
                    contentPadding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
                    leading: Container(
                      width: 48, height: 48,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: col.withOpacity(0.12),
                        border: Border.all(color: col.withOpacity(0.3), width: 1.5)),
                      child: Center(child: Text('${item.overallScore.toInt()}%',
                        style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 13))),
                    ),
                    title: Text(item.soilType, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                    subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const SizedBox(height: 3),
                      Text(dateStr, style: TextStyle(color: Colors.grey[400], fontSize: 12)),
                      const SizedBox(height: 4),
                      Row(children: [
                        _NutrientChip('N', item.nitrogenLevel),
                        const SizedBox(width: 4),
                        _NutrientChip('P', item.phosphorusLevel),
                        const SizedBox(width: 4),
                        _NutrientChip('K', item.potassiumLevel),
                      ]),
                    ]),
                    isThreeLine: true,
                    trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: col.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                        child: Text(item.status.split(' ').first, style: TextStyle(color: col, fontSize: 10, fontWeight: FontWeight.w600)),
                      ),
                      const SizedBox(height: 6),
                      const Icon(Icons.chevron_right, color: Colors.grey, size: 18),
                    ]),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CameraResultScreen(result: item))),
                  ),
                ),
              );
            },
          ),
      bottomNavigationBar: AppBottomNav(selectedIndex: 0, onTap: (_) => Navigator.pop(context)),
    );
  }
}

class _NutrientChip extends StatelessWidget {
  final String label, level;
  const _NutrientChip(this.label, this.level);
  Color get _col {
    switch (level.toLowerCase()) {
      case 'high': return const Color(0xFF43A047);
      case 'medium': return Colors.orange;
      default: return Colors.red;
    }
  }
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
    decoration: BoxDecoration(color: _col.withOpacity(0.1), borderRadius: BorderRadius.circular(5),
      border: Border.all(color: _col.withOpacity(0.3))),
    child: Text('$label: $level', style: TextStyle(color: _col, fontSize: 9, fontWeight: FontWeight.w600)),
  );
}
