import 'package:flutter/material.dart';
import '../models/soil_data_service.dart';
import '../widgets/bottom_nav.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});
  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final _svc = SoilDataService.instance;

  void _openNoteDialog({int? editIndex}) {
    final titleCtrl = TextEditingController(
        text: editIndex != null ? _svc.notes[editIndex]['title'] : '');
    final bodyCtrl = TextEditingController(
        text: editIndex != null ? _svc.notes[editIndex]['body'] : '');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
            left: 16, right: 16, top: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)))),
          Text(editIndex != null ? 'Edit Note' : 'New Note',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          TextField(controller: titleCtrl, decoration: InputDecoration(
            labelText: 'Title', prefixIcon: const Icon(Icons.title_outlined),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
          const SizedBox(height: 10),
          TextField(controller: bodyCtrl, maxLines: 4, decoration: InputDecoration(
            labelText: 'Note', alignLabelWithHint: true,
            prefixIcon: const Padding(padding: EdgeInsets.only(bottom: 60), child: Icon(Icons.notes_outlined)),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: () => Navigator.pop(context), child: const Text('Cancel'))),
            const SizedBox(width: 10),
            Expanded(child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4E7A3E)),
              onPressed: () {
                if (titleCtrl.text.trim().isNotEmpty) {
                  final now = DateTime.now();
                  final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
                  final note = {
                    'title': titleCtrl.text.trim(),
                    'body': bodyCtrl.text.trim(),
                    'date': '${months[now.month-1]} ${now.day}, ${now.year}',
                  };
                  setState(() {
                    if (editIndex != null) _svc.updateNote(editIndex, note);
                    else _svc.addNote(note);
                  });
                }
                Navigator.pop(context);
              },
              child: const Text('Save', style: TextStyle(color: Colors.white)))),
          ]),
        ]),
      ),
    );
  }

  void _deleteNote(int index) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Delete Note'),
      content: const Text('Are you sure you want to delete this note?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          onPressed: () { setState(() => _svc.removeNote(index)); Navigator.pop(context); },
          child: const Text('Delete', style: TextStyle(color: Colors.white))),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final notes = _svc.notes;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Notes', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white, elevation: 0, foregroundColor: Colors.black, centerTitle: true,
        actions: [IconButton(
          icon: const Icon(Icons.add, color: Color(0xFF4E7A3E)),
          onPressed: () => _openNoteDialog())],
      ),
      body: notes.isEmpty
        ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.note_alt_outlined, size: 72, color: Colors.grey[300]),
            const SizedBox(height: 12),
            const Text('No notes yet', style: TextStyle(color: Colors.grey, fontSize: 15)),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4E7A3E)),
              onPressed: () => _openNoteDialog(),
              icon: const Icon(Icons.add, color: Colors.white),
              label: const Text('Add Your First Note', style: TextStyle(color: Colors.white))),
          ]))
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: notes.length,
            itemBuilder: (context, i) {
              final note = notes[i];
              return Dismissible(
                key: Key('note_$i'),
                direction: DismissDirection.endToStart,
                background: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(12)),
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  child: const Icon(Icons.delete_outline, color: Colors.white)),
                confirmDismiss: (_) async { _deleteNote(i); return false; },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF4E7A3E).withOpacity(0.05),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFF4E7A3E).withOpacity(0.15))),
                  child: ListTile(
                    contentPadding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
                    title: Text(note['title']!, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                    subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const SizedBox(height: 4),
                      Text(note['body']!, maxLines: 2, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 13, color: Colors.black54)),
                      const SizedBox(height: 6),
                      Text(note['date']!, style: TextStyle(color: Colors.grey[400], fontSize: 11)),
                    ]),
                    isThreeLine: true,
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.edit_outlined, size: 20, color: Color(0xFF4E7A3E)),
                        onPressed: () => _openNoteDialog(editIndex: i)),
                      IconButton(icon: const Icon(Icons.delete_outline, size: 20, color: Colors.red),
                        onPressed: () => _deleteNote(i)),
                    ]),
                  ),
                ),
              );
            }),
      bottomNavigationBar: AppBottomNav(selectedIndex: 0, onTap: (_) => Navigator.pop(context)),
    );
  }
}
