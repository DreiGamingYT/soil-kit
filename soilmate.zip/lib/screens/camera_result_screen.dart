import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/soil_result.dart';
import '../models/soil_data_service.dart';

class CameraResultScreen extends StatelessWidget {
  final SoilResult result;
  const CameraResultScreen({super.key, required this.result});

  Color get _scoreColor {
    if (result.overallScore >= 70) return const Color(0xFF43A047);
    if (result.overallScore >= 45) return Colors.orange;
    return Colors.red;
  }

  String _months(int m) => const ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][m-1];

  void _showRecommendations(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.65, maxChildSize: 0.92, minChildSize: 0.4, expand: false,
        builder: (_, ctrl) => SingleChildScrollView(
          controller: ctrl,
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)))),
            const Text('Recommendations', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('Based on your ${result.soilType} analysis', style: TextStyle(color: Colors.grey[500], fontSize: 13)),
            const SizedBox(height: 20),
            if (result.nitrogenLevel == 'Low') _RecCard(
              icon: Icons.grass, color: Colors.red,
              title: 'Nitrogen Deficiency',
              body: 'Apply urea (46-0-0) or ammonium nitrate at 50–100 kg/ha. Consider green manure crops like clover or legumes to fix nitrogen naturally.',
            ),
            if (result.phosphorusLevel == 'Low') _RecCard(
              icon: Icons.water_drop, color: Colors.orange,
              title: 'Phosphorus Deficiency',
              body: 'Apply superphosphate or triple superphosphate. Bone meal is a good organic option. Target pH 6–7 for maximum phosphorus availability.',
            ),
            if (result.potassiumLevel == 'Low') _RecCard(
              icon: Icons.eco, color: Colors.amber[700]!,
              title: 'Potassium Deficiency',
              body: 'Apply muriate of potash (0-0-60) or sulfate of potash. Wood ash is a natural source. Ensure adequate soil moisture for uptake.',
            ),
            if (result.ph < 6.0) _RecCard(
              icon: Icons.science, color: Colors.purple,
              title: 'Acidic Soil (pH ${result.ph})',
              body: 'Apply agricultural lime (calcium carbonate) at 1–3 tonnes/ha to raise pH. Dolomite lime also adds magnesium. Retest after 3 months.',
            ),
            if (result.ph > 7.5) _RecCard(
              icon: Icons.science, color: Colors.blue,
              title: 'Alkaline Soil (pH ${result.ph})',
              body: 'Apply elemental sulfur or acidifying fertilizers. Iron chelates help prevent micronutrient deficiency. Organic matter can lower pH over time.',
            ),
            if (result.nitrogenLevel == 'High' && result.phosphorusLevel == 'High' && result.potassiumLevel == 'High') _RecCard(
              icon: Icons.check_circle_outline, color: const Color(0xFF4E7A3E),
              title: 'Soil is Well Nourished',
              body: 'Your soil has good nutrient levels. Maintain with regular organic matter additions. Monitor every season to prevent over-fertilization.',
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: const Color(0xFF4E7A3E).withOpacity(0.06),
                border: Border.all(color: const Color(0xFF4E7A3E).withOpacity(0.2)),
                borderRadius: BorderRadius.circular(12)),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.lightbulb_outline, color: Color(0xFF4E7A3E), size: 20),
                const SizedBox(width: 10),
                const Expanded(child: Text(
                  'Retest your soil after applying amendments (4–8 weeks) to confirm improvement. Always follow local agronomist guidance for your specific crop.',
                  style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.5))),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  void _saveResult(BuildContext context) {
    SoilDataService.instance.addResult(result);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Row(children: [
          Icon(Icons.check_circle, color: Colors.white, size: 18),
          SizedBox(width: 8),
          Text('Result saved to history!'),
        ]),
        backgroundColor: Color(0xFF4E7A3E),
        duration: Duration(seconds: 2),
      ),
    );
    Navigator.popUntil(context, (r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final dateStr = '${_months(result.date.month)} ${result.date.day}, ${result.date.year}';
    return Scaffold(
      backgroundColor: const Color(0xFFF5F0E8),
      body: Column(children: [
        // Green header
        Container(
          color: const Color(0xFF4E7A3E),
          padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 8, left: 8, right: 16, bottom: 14),
          child: Row(children: [
            IconButton(icon: const Icon(Icons.chevron_left, color: Colors.white, size: 28), onPressed: () => Navigator.pop(context)),
            const Spacer(),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(result.soilType, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
              Text(dateStr, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ]),
            const SizedBox(width: 10),
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.brown[400]),
              clipBehavior: Clip.antiAlias,
              child: result.imagePath != null && File(result.imagePath!).existsSync()
                ? Image.file(File(result.imagePath!), fit: BoxFit.cover)
                : const Icon(Icons.terrain, color: Colors.white, size: 28),
            ),
          ]),
        ),

        Expanded(child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            // Donut chart card
            Container(
              width: double.infinity, padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(16)),
              child: Column(children: [
                SizedBox(width: 180, height: 180,
                  child: CustomPaint(
                    painter: DonutChartPainter(result: result),
                    child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text('${result.overallScore.toInt()}%',
                        style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: _scoreColor)),
                      const Text('Overall Status:', style: TextStyle(fontSize: 10, color: Colors.black54)),
                      Text(result.status, textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 10, color: Colors.black54)),
                    ])),
                  ),
                ),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  _LegendDot(color: Colors.red, label: 'N'),
                  const SizedBox(width: 16),
                  _LegendDot(color: Colors.orange, label: 'P'),
                  const SizedBox(width: 16),
                  _LegendDot(color: const Color(0xFF43A047), label: 'K'),
                ]),
              ]),
            ),
            const SizedBox(height: 12),

            // Summary card
            Container(
              width: double.infinity, padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Summary', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _NutrientRow(label: 'Nitrogen (N)', value: result.nitrogenLevel, dotColor: Colors.red),
                _NutrientRow(label: 'Phosphorus (P)', value: result.phosphorusLevel, dotColor: Colors.orange),
                _NutrientRow(label: 'Potassium (K)', value: result.potassiumLevel, dotColor: const Color(0xFF43A047)),
                const Divider(height: 20),
                Row(children: [
                  const Icon(Icons.science_outlined, size: 16, color: Colors.grey),
                  const SizedBox(width: 6),
                  Text('pH: ${result.ph}  (${result.phDescription})',
                    style: const TextStyle(fontSize: 13, color: Colors.black54)),
                ]),
              ]),
            ),
            const SizedBox(height: 12),

            // View recommendations
            SizedBox(width: double.infinity, height: 48,
              child: ElevatedButton.icon(
                onPressed: () => _showRecommendations(context),
                icon: const Icon(Icons.lightbulb_outline, size: 18),
                label: const Text('View Recommendations'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4E7A3E), foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Discard / Save
            Row(children: [
              Expanded(child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                child: const Text('Discard'),
              )),
              const SizedBox(width: 12),
              Expanded(child: ElevatedButton.icon(
                onPressed: () => _saveResult(context),
                icon: const Icon(Icons.save_alt_outlined, size: 18),
                label: const Text('Save'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white, foregroundColor: Colors.black87,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: BorderSide(color: Colors.grey.shade300)),
                  elevation: 0,
                ),
              )),
            ]),
            const SizedBox(height: 16),
          ]),
        )),
      ]),
    );
  }
}

class _LegendDot extends StatelessWidget {
  final Color color; final String label;
  const _LegendDot({required this.color, required this.label});
  @override
  Widget build(BuildContext context) => Row(children: [
    Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
    const SizedBox(width: 4),
    Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
  ]);
}

class _NutrientRow extends StatelessWidget {
  final String label, value; final Color dotColor;
  const _NutrientRow({required this.label, required this.value, required this.dotColor});

  Color get _valColor {
    switch (value.toLowerCase()) {
      case 'low': return Colors.red;
      case 'medium': return Colors.orange;
      case 'high': return const Color(0xFF43A047);
      default: return Colors.black;
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      Container(width: 10, height: 10, decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle)),
      const SizedBox(width: 10),
      Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14))),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(
          color: _valColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _valColor.withOpacity(0.3)),
        ),
        child: Text(value, style: TextStyle(color: _valColor, fontSize: 13, fontWeight: FontWeight.w600)),
      ),
    ]),
  );
}

class _RecCard extends StatelessWidget {
  final IconData icon; final Color color; final String title, body;
  const _RecCard({required this.icon, required this.color, required this.title, required this.body});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: color.withOpacity(0.05),
      border: Border.all(color: color.withOpacity(0.25)),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 8),
        Text(title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: color)),
      ]),
      const SizedBox(height: 8),
      Text(body, style: const TextStyle(fontSize: 13, color: Colors.black54, height: 1.5)),
    ]),
  );
}

class DonutChartPainter extends CustomPainter {
  final SoilResult result;
  DonutChartPainter({required this.result});

  Color _colorFor(String level) {
    switch (level.toLowerCase()) {
      case 'high': return const Color(0xFF43A047);
      case 'medium': return Colors.orange;
      default: return Colors.red;
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 12;
    const strokeWidth = 26.0;
    final paint = Paint()..style = PaintingStyle.stroke..strokeWidth = strokeWidth..strokeCap = StrokeCap.butt;

    // Background ring
    paint.color = Colors.grey.shade300;
    canvas.drawCircle(center, radius, paint);

    final segments = [
      {'color': _colorFor(result.nitrogenLevel), 'label': 'N'},
      {'color': _colorFor(result.phosphorusLevel), 'label': 'P'},
      {'color': _colorFor(result.potassiumLevel), 'label': 'K'},
    ];

    final sweep = (2 * math.pi) / 3;
    for (int i = 0; i < segments.length; i++) {
      paint.color = segments[i]['color'] as Color;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        -math.pi / 2 + i * sweep + 0.04,
        sweep - 0.08,
        false, paint,
      );
    }
  }

  @override
  bool shouldRepaint(_) => false;
}
