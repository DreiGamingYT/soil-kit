import 'package:flutter/material.dart';
import '../models/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _s = SettingsService.instance;

  // ── Notification permission dialog (simulates OS permission prompt) ──
  void _requestNotificationPermission(bool requestingOn) async {
    if (!requestingOn) {
      setState(() => _s.notificationsEnabled.value = false);
      return;
    }
    if (_s.notificationPermissionGranted.value) {
      setState(() => _s.notificationsEnabled.value = true);
      return;
    }

    final granted = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
                width: 64, height: 64,
                decoration: BoxDecoration(
                    color: const Color(0xFF4E7A3E).withOpacity(0.1),
                    shape: BoxShape.circle),
                child: const Icon(Icons.notifications_outlined,
                    size: 32, color: Color(0xFF4E7A3E))),
            const SizedBox(height: 16),
            const Text('"Soil App" Would Like to\nSend You Notifications',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(
                'Notifications may include soil test reminders, weekly field alerts, and tips to improve your soil health.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.grey[600], height: 1.5)),
            const SizedBox(height: 24),
            Row(children: [
              Expanded(child: OutlinedButton(
                  onPressed: () => Navigator.pop(context, false),
                  style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 13)),
                  child: const Text("Don't Allow"))),
              const SizedBox(width: 12),
              Expanded(child: ElevatedButton(
                  onPressed: () => Navigator.pop(context, true),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF4E7A3E),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 13)),
                  child: const Text('Allow'))),
            ]),
          ]),
        ),
      ),
    );

    if (granted == true) {
      setState(() {
        _s.notificationPermissionGranted.value = true;
        _s.notificationsEnabled.value = true;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Row(children: [
            Icon(Icons.check_circle, color: Colors.white, size: 16),
            SizedBox(width: 8),
            Text('Notifications enabled'),
          ]),
          backgroundColor: Color(0xFF4E7A3E),
          duration: Duration(seconds: 2),
        ));
      }
    } else {
      setState(() {
        _s.notificationsEnabled.value = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('Notifications blocked. Enable in device Settings > Soil App.'),
          backgroundColor: Colors.grey[700],
          duration: const Duration(seconds: 3),
          action: SnackBarAction(
            label: 'OK',
            textColor: Colors.white,
            onPressed: () {},
          ),
        ));
      }
    }
  }

  void _clearHistory() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear History'),
        content: const Text('This will permanently delete all saved soil test results. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () {
                Navigator.pop(context);
                // Import SoilDataService here would create circular deps — use global import
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('History cleared.'),
                    backgroundColor: Color(0xFF4E7A3E)));
              },
              child: const Text('Delete All', style: TextStyle(color: Colors.white))),
        ],
      ),
    );
  }

  void _exportData() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Data exported to Downloads/soil_data.csv'),
        backgroundColor: Color(0xFF4E7A3E)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFF1A1A1A)
          : Colors.grey[50],
      appBar: AppBar(
        title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF4E7A3E),
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: ValueListenableBuilder<bool>(
        valueListenable: _s.notificationsEnabled,
        builder: (_, notif, __) => ValueListenableBuilder<bool>(
          valueListenable: _s.autoAnalyze,
          builder: (_, auto, __) => ValueListenableBuilder<bool>(
            valueListenable: _s.autoSavePhotos,
            builder: (_, save, __) => ValueListenableBuilder<ThemeMode>(
              valueListenable: _s.themeMode,
              builder: (_, mode, __) => ValueListenableBuilder<String>(
                valueListenable: _s.measurementUnit,
                builder: (_, unit, __) => ValueListenableBuilder<String>(
                  valueListenable: _s.language,
                  builder: (_, lang, __) => ListView(
                    padding: const EdgeInsets.all(16),
                    children: [

                      // ── NOTIFICATIONS ────────────────────────────────
                      _SectionHeader(title: 'Notifications'),
                      _ToggleTile(
                        icon: Icons.notifications_outlined,
                        title: 'Push Notifications',
                        subtitle: notif && _s.notificationPermissionGranted.value
                            ? 'Active — you will receive soil reminders'
                            : 'Tap to request permission',
                        value: notif,
                        onChanged: _requestNotificationPermission,
                        statusBadge: notif && _s.notificationPermissionGranted.value
                            ? _Badge('ON', Colors.green)
                            : !_s.notificationPermissionGranted.value
                            ? _Badge('PERMISSION NEEDED', Colors.orange)
                            : null,
                      ),

                      const SizedBox(height: 16),

                      // ── CAMERA & ANALYSIS ────────────────────────────
                      _SectionHeader(title: 'Camera & Analysis'),
                      _ToggleTile(
                        icon: Icons.auto_fix_high_outlined,
                        title: 'Auto-Analyze on Capture',
                        subtitle: auto
                            ? 'Analysis starts automatically after photo'
                            : 'You will tap Analyze manually',
                        value: auto,
                        onChanged: (v) => setState(() => _s.autoAnalyze.value = v),
                      ),
                      _ToggleTile(
                        icon: Icons.save_alt_outlined,
                        title: 'Auto-save Photos',
                        subtitle: save
                            ? 'Captured photos saved to gallery'
                            : 'Photos are not saved to gallery',
                        value: save,
                        onChanged: (v) {
                          setState(() => _s.autoSavePhotos.value = v);
                          if (v) {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                                content: Text('Photos will be saved to your gallery'),
                                backgroundColor: Color(0xFF4E7A3E)));
                          }
                        },
                      ),

                      const SizedBox(height: 16),

                      // ── DISPLAY ───────────────────────────────────────
                      _SectionHeader(title: 'Display'),
                      _ToggleTile(
                        icon: Icons.dark_mode_outlined,
                        title: 'Dark Mode',
                        subtitle: mode == ThemeMode.dark
                            ? 'Dark theme is active'
                            : 'Using light theme',
                        value: mode == ThemeMode.dark,
                        onChanged: (v) {
                          _s.toggleDarkMode(v);
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content: Text(v ? 'Dark mode enabled' : 'Light mode enabled'),
                              backgroundColor: const Color(0xFF4E7A3E),
                              duration: const Duration(seconds: 1)));
                        },
                      ),
                      _DropdownTile(
                        icon: Icons.straighten_outlined,
                        title: 'Measurement Unit',
                        subtitle: 'Unit for nutrient concentrations',
                        value: unit,
                        options: const ['mg/kg', 'ppm', 'g/L', 'cmol/kg'],
                        onChanged: (v) {
                          if (v != null) {
                            setState(() => _s.measurementUnit.value = v);
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: Text('Unit changed to $v'),
                                backgroundColor: const Color(0xFF4E7A3E),
                                duration: const Duration(seconds: 1)));
                          }
                        },
                      ),
                      _DropdownTile(
                        icon: Icons.language_outlined,
                        title: 'Language',
                        subtitle: 'App display language',
                        value: lang,
                        options: const ['English', 'Filipino', 'Spanish', 'Mandarin'],
                        onChanged: (v) {
                          if (v != null) {
                            setState(() => _s.language.value = v);
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: Text('Language set to $v'),
                                backgroundColor: const Color(0xFF4E7A3E),
                                duration: const Duration(seconds: 1)));
                          }
                        },
                      ),

                      const SizedBox(height: 16),

                      // ── DATA & PRIVACY ────────────────────────────────
                      _SectionHeader(title: 'Data & Privacy'),
                      _ActionTile(
                        icon: Icons.delete_outline,
                        title: 'Clear History',
                        subtitle: 'Delete all saved soil test results',
                        color: Colors.red,
                        onTap: _clearHistory,
                      ),
                      _ActionTile(
                        icon: Icons.download_outlined,
                        title: 'Export Data',
                        subtitle: 'Export all results as a CSV file',
                        onTap: _exportData,
                      ),

                      const SizedBox(height: 16),

                      // ── ABOUT ─────────────────────────────────────────
                      _SectionHeader(title: 'About'),
                      _InfoTile(icon: Icons.apps, title: 'App Version', value: '1.0.0'),
                      _InfoTile(icon: Icons.build_outlined, title: 'Build', value: '2026.03'),
                      _ActionTile(
                        icon: Icons.info_outline,
                        title: 'About the App',
                        subtitle: 'Developers & acknowledgements',
                        onTap: () => _showAbout(context),
                      ),
                      _ActionTile(
                        icon: Icons.policy_outlined,
                        title: 'Privacy Policy',
                        onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Privacy Policy coming soon.'))),
                      ),

                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showAbout(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── Fixed header ─────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
              child: Column(children: [
                Container(
                    width: 70, height: 70,
                    decoration: BoxDecoration(
                        color: const Color(0xFF4E7A3E).withOpacity(0.1),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.eco, size: 38, color: Color(0xFF4E7A3E))),
                const SizedBox(height: 14),
                const Text('SoilMate',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const Text('Version 1.0.0',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                const SizedBox(height: 16),
                const Divider(),
              ]),
            ),
            // ── Scrollable body ──────────────────────────────────────
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 12),
                    const Center(
                      child: Text('GTECH SOLUTION COMPANY',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold,
                              letterSpacing: 1.5, color: Colors.grey)),
                    ),
                    const SizedBox(height: 12),
                    _DevRow(name: 'CEO', value: 'Bolatin, Jane Alexa'),
                    _DevRow(name: 'Product/Marketing Lead', value: 'Garde, Denise Kenchien'),
                    _DevRow(name: 'Content Specialist', value: 'Dayna, John Mark'),
                    _DevRow(name: 'Technical Lead', value: 'Velasco, Jonathan'),
                    _DevRow(name: 'UI/UX Designer', value: 'Suagen, Allysa Jasmin'),
                    _DevRow(name: 'Software Developer', value: 'De Guzman, Maenalyn'),
                    _DevRow(name: 'Finance Manager', value: 'Ilagor, Paul John'),
                    _DevRow(name: 'Documentation Specialist', value: 'Malabiga, Yui Rave'),
                    _DevRow(name: 'Records Coordinator', value: 'Siarot, Reydin'),
                    _DevRow(name: 'Research & Feature Lead', value: 'Anza Jr., Jonathan'),
                    _DevRow(name: 'Quality Assurance', value: 'Delos Reyes'),
                    const SizedBox(height: 12),
                    const Divider(),
                    const SizedBox(height: 8),
                    Center(
                      child: Text('© 2026 Soil App Team. All rights reserved.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey[500], fontSize: 11)),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
            // ── Fixed footer ─────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 20),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4E7A3E),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    child: const Text('Close')),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Reusable widgets ─────────────────────────────────────────────────────────

class _Badge extends StatelessWidget {
  final String text; final Color color;
  const _Badge(this.text, this.color);
  @override
  Widget build(BuildContext context) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(6), border: Border.all(color: color.withOpacity(0.3))),
      child: Text(text, style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.bold)));
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});
  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(title.toUpperCase(),
          style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold,
              color: Colors.grey[500], letterSpacing: 1.2)));
}

class _ToggleTile extends StatelessWidget {
  final IconData icon; final String title; final String? subtitle;
  final bool value; final ValueChanged<bool> onChanged;
  final Widget? statusBadge;
  const _ToggleTile({required this.icon, required this.title, this.subtitle,
    required this.value, required this.onChanged, this.statusBadge});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF2A2A2A) : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade200)),
    child: ListTile(
      leading: Icon(icon, color: const Color(0xFF4E7A3E)),
      title: Row(children: [
        Flexible(
            child: Text(title,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                overflow: TextOverflow.ellipsis)),
        if (statusBadge != null) ...[const SizedBox(width: 6), statusBadge!],
      ]),
      subtitle: subtitle != null
          ? Text(subtitle!, style: const TextStyle(fontSize: 12), maxLines: 2)
          : null,
      trailing: Switch(value: value, onChanged: onChanged, activeColor: const Color(0xFF4E7A3E)),
    ),
  );
}

class _DropdownTile extends StatelessWidget {
  final IconData icon; final String title; final String? subtitle;
  final String value; final List<String> options; final ValueChanged<String?> onChanged;
  const _DropdownTile({required this.icon, required this.title, this.subtitle,
    required this.value, required this.options, required this.onChanged});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF2A2A2A) : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade200)),
    child: ListTile(
      leading: Icon(icon, color: const Color(0xFF4E7A3E)),
      title: Text(title,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
          overflow: TextOverflow.ellipsis),
      subtitle: subtitle != null
          ? Text(subtitle!, style: const TextStyle(fontSize: 12), maxLines: 2)
          : null,
      trailing: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 120),
        child: DropdownButton<String>(
            value: value,
            underline: const SizedBox(),
            isExpanded: true,
            style: const TextStyle(color: Color(0xFF4E7A3E), fontWeight: FontWeight.w600, fontSize: 13),
            items: options.map((o) => DropdownMenuItem(value: o, child: Text(o, overflow: TextOverflow.ellipsis))).toList(),
            onChanged: onChanged),
      ),
    ),
  );
}

class _ActionTile extends StatelessWidget {
  final IconData icon; final String title; final String? subtitle;
  final Color? color; final VoidCallback onTap;
  const _ActionTile({required this.icon, required this.title, this.subtitle, this.color, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final c = color ?? Colors.black87;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF2A2A2A) : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.shade200)),
      child: ListTile(
          leading: Icon(icon, color: c),
          title: Text(title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: c)),
          subtitle: subtitle != null ? Text(subtitle!, style: const TextStyle(fontSize: 12)) : null,
          trailing: Icon(Icons.chevron_right, color: Colors.grey[400]),
          onTap: onTap),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon; final String title, value;
  const _InfoTile({required this.icon, required this.title, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF2A2A2A) : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade200)),
    child: ListTile(
        leading: Icon(icon, color: const Color(0xFF4E7A3E)),
        title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
        trailing: Text(value, style: TextStyle(color: Colors.grey[500], fontSize: 13))),
  );
}

class _DevRow extends StatelessWidget {
  final String name, value;
  const _DevRow({required this.name, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      SizedBox(width: 120, child: Text(name, style: const TextStyle(fontSize: 12, color: Colors.grey))),
      Expanded(child: Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
    ]),
  );
}