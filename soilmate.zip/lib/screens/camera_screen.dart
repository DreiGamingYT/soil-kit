import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../models/soil_result.dart';
import 'camera_result_screen.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  Soil detection state
// ─────────────────────────────────────────────────────────────────────────────
enum _DetectState { scanning, soilFound, noSoil }

// ─────────────────────────────────────────────────────────────────────────────
//  CameraScreen
// ─────────────────────────────────────────────────────────────────────────────
class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen>
    with TickerProviderStateMixin {
  // ── Camera ────────────────────────────────────────────────────────────────
  CameraController? _ctrl;
  List<CameraDescription> _cameras = [];
  bool _camReady = false;
  bool _camError = false;
  String _errorMsg = '';
  bool _torchOn = false; // manual torch — off by default

  // ── Soil detection via image stream ───────────────────────────────────────
  _DetectState _detectState = _DetectState.scanning;
  double _soilConfidence = 0.0;
  int _frameCount = 0;          // throttle: process 1 in N frames
  static const int _kSampleEvery = 20; // ~1 analysis/sec at 20 fps
  bool _streamProcessing = false;

  // ── Capture / analyse ─────────────────────────────────────────────────────
  bool _isCapturing = false;
  bool _isAnalyzing = false;

  // ── Animations ────────────────────────────────────────────────────────────
  late AnimationController _pulseCtrl;
  late AnimationController _scanLineCtrl;
  late Animation<double> _scanLineAnim;
  late AnimationController _cornerCtrl;
  late Animation<double> _cornerAnim;

  // ─────────────────────────────────────────────────────────────────────────
  Color get _stateColor {
    switch (_detectState) {
      case _DetectState.soilFound: return const Color(0xFF4CAF50);
      case _DetectState.noSoil:   return const Color(0xFFFF5722);
      case _DetectState.scanning: return const Color(0xFFFFD600);
    }
  }

  String get _stateLabel {
    switch (_detectState) {
      case _DetectState.soilFound: return 'Soil Detected  ✓';
      case _DetectState.noSoil:   return 'No soil — aim at sample';
      case _DetectState.scanning: return 'Scanning…';
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);

    _scanLineCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat();
    _scanLineAnim =
        CurvedAnimation(parent: _scanLineCtrl, curve: Curves.linear);

    _cornerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 350));
    _cornerAnim =
        CurvedAnimation(parent: _cornerCtrl, curve: Curves.easeOut);

    _initCamera();
  }

  @override
  void dispose() {
    _ctrl?.stopImageStream();
    _ctrl?.dispose();
    _pulseCtrl.dispose();
    _scanLineCtrl.dispose();
    _cornerCtrl.dispose();
    super.dispose();
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Camera init
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _initCamera() async {
    try {
      _cameras = await availableCameras();
      if (_cameras.isEmpty) {
        setState(() { _camError = true; _errorMsg = 'No cameras found.'; });
        return;
      }
      // Prefer rear camera
      final rear = _cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => _cameras.first,
      );
      _ctrl = CameraController(
        rear,
        ResolutionPreset.medium,
        enableAudio: false,
        // Let the plugin pick the best native format:
        // Android → NV21 (default), iOS → BGRA8888
        imageFormatGroup: ImageFormatGroup.yuv420,
      );
      await _ctrl!.initialize();
      // Flash OFF by default — never auto
      await _ctrl!.setFlashMode(FlashMode.off);
      if (!mounted) return;
      setState(() { _camReady = true; _camError = false; });
      _startImageStream();
    } on CameraException catch (e) {
      setState(() {
        _camError = true;
        _errorMsg = e.description ?? 'Camera failed to start.';
      });
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Image stream — lightweight soil detection
  //  Uses raw YUV420 Y-plane for speed. No disk I/O at all.
  // ─────────────────────────────────────────────────────────────────────────
  void _startImageStream() {
    _ctrl?.startImageStream((CameraImage frame) {
      _frameCount++;
      if (_frameCount % _kSampleEvery != 0) return;
      if (_streamProcessing || _isCapturing || _isAnalyzing) return;
      _streamProcessing = true;
      _analyzeFrame(frame);
    });
  }

  void _analyzeFrame(CameraImage frame) {
    try {
      final w = frame.width;
      final h = frame.height;

      // Centre crop — 40% of the frame
      final x0 = (w * 0.30).toInt();
      final x1 = (w * 0.70).toInt();
      final y0 = (h * 0.30).toInt();
      final y1 = (h * 0.70).toInt();

      double r = 128, g = 128, b = 128;

      final fmt = frame.format.group;

      if (fmt == ImageFormatGroup.bgra8888) {
        // ── iOS (BGRA8888) — 4 bytes per pixel ──────────────────────
        final plane = frame.planes[0];
        double rS = 0, gS = 0, bS = 0;
        int cnt = 0;
        for (int py = y0; py < y1; py += 6) {
          for (int px = x0; px < x1; px += 6) {
            final i = py * plane.bytesPerRow + px * 4;
            if (i + 2 < plane.bytes.length) {
              bS += plane.bytes[i];
              gS += plane.bytes[i + 1];
              rS += plane.bytes[i + 2];
              cnt++;
            }
          }
        }
        if (cnt > 0) { r = rS / cnt; g = gS / cnt; b = bS / cnt; }

      } else {
        // ── Android: YUV420 / NV21 / NV12 ────────────────────────────
        // plane[0] = Y (always 1 byte per pixel)
        // plane[1] = U or V (interleaved if bytesPerPixel==2 → NV12/NV21)
        // plane[2] = V or U (only present in I420)
        final yPlane = frame.planes[0];

        // Sample Y (luma)
        double yS = 0;
        int yCnt = 0;
        for (int py = y0; py < y1; py += 6) {
          for (int px = x0; px < x1; px += 6) {
            final i = py * yPlane.bytesPerRow + px;
            if (i < yPlane.bytes.length) {
              yS += yPlane.bytes[i] & 0xFF;
              yCnt++;
            }
          }
        }
        final yAvg = yCnt > 0 ? yS / yCnt : 128.0;

        // Sample chroma
        double uAvg = 128.0, vAvg = 128.0;

        if (frame.planes.length >= 2) {
          final plane1 = frame.planes[1];
          // bytesPerPixel == 2  →  interleaved (NV12 or NV21)
          // bytesPerPixel == 1  →  separate planes (I420)
          final pixStride = plane1.bytesPerPixel ?? 1;
          final interleaved = pixStride == 2;

          double u1S = 0, v1S = 0;
          int uvCnt = 0;

          for (int py = y0 ~/ 2; py < y1 ~/ 2; py += 3) {
            for (int px = x0 ~/ 2; px < x1 ~/ 2; px += 3) {
              if (interleaved) {
                // NV21: plane1 = [V, U, V, U …]
                // NV12: plane1 = [U, V, U, V …]
                // We detect NV21 vs NV12 by checking plane count:
                // NV21 has 2 planes (plane[2] absent or same buffer as plane[1])
                final idx = py * plane1.bytesPerRow + px * 2;
                if (idx + 1 < plane1.bytes.length) {
                  // Assume NV21 (most common Android): first=V, second=U
                  v1S += plane1.bytes[idx] & 0xFF;
                  u1S += plane1.bytes[idx + 1] & 0xFF;
                  uvCnt++;
                }
              } else {
                // I420: plane[1]=U, plane[2]=V
                final idx = py * plane1.bytesPerRow + px;
                if (idx < plane1.bytes.length) {
                  u1S += plane1.bytes[idx] & 0xFF;
                  uvCnt++;
                }
                if (frame.planes.length >= 3) {
                  final plane2 = frame.planes[2];
                  final vIdx = py * plane2.bytesPerRow + px;
                  if (vIdx < plane2.bytes.length) {
                    v1S += plane2.bytes[vIdx] & 0xFF;
                  }
                }
              }
            }
          }

          if (uvCnt > 0) {
            uAvg = u1S / uvCnt;
            vAvg = v1S / uvCnt;
          }
        }

        // YCbCr → RGB  (BT.601)
        r = (yAvg + 1.402  * (vAvg - 128)).clamp(0, 255).toDouble();
        g = (yAvg - 0.344  * (uAvg - 128) - 0.714 * (vAvg - 128)).clamp(0, 255).toDouble();
        b = (yAvg + 1.772  * (uAvg - 128)).clamp(0, 255).toDouble();
      }

      final confidence = _calcSoilConfidence(r, g, b);

      if (!mounted) { _streamProcessing = false; return; }

      final prev = _detectState;
      setState(() {
        _soilConfidence = confidence;
        if (confidence >= 0.42) {
          _detectState = _DetectState.soilFound;
        } else if (confidence >= 0.20) {
          _detectState = _DetectState.scanning;
        } else {
          _detectState = _DetectState.noSoil;
        }
      });

      if (prev != _detectState) _cornerCtrl.forward(from: 0);
    } catch (_) {
      // Silent — keep looping
    }
    _streamProcessing = false;
  }

  /// Soil confidence scorer — flash-aware, works on all soil types.
  ///
  /// Strategy: EXCLUSION first (rule out sky / grass / water),
  /// then POSITIVE scoring on warm-tone cues.
  /// Flash desaturates & brightens — we don't penalise that.
  double _calcSoilConfidence(double r, double g, double b) {

    // ── Hard exclusions ──────────────────────────────────────────────
    // Sky / water: blue dominant
    if (b > r + 18 && b > g) return 0.05;
    // Grass / leaves: green clearly dominant over red
    if (g > r + 18 && g > b + 10) return 0.05;
    // Pure white overexposure (all channels > 230)
    if (r > 230 && g > 230 && b > 230) return 0.10;
    // Pure black / lens cap
    if (r < 15 && g < 15 && b < 15) return 0.0;

    // ── HSV conversion ───────────────────────────────────────────────
    final rf = r / 255, gf = g / 255, bf = b / 255;
    final maxC = [rf, gf, bf].reduce(math.max);
    final minC = [rf, gf, bf].reduce(math.min);
    final delta = maxC - minC;

    double h = 0;
    if (delta > 0) {
      if (maxC == rf)      h = 60 * (((gf - bf) / delta) % 6);
      else if (maxC == gf) h = 60 * (((bf - rf) / delta) + 2);
      else                 h = 60 * (((rf - gf) / delta) + 4);
      if (h < 0) h += 360;
    }
    final s = maxC == 0 ? 0.0 : delta / maxC;

    double score = 0.0;

    // ── Hue scoring (broad — covers all soil types + flash shift) ────
    // Core soil hues: red-brown to yellow-tan (0°–90°)
    if (h >= 0 && h <= 90) {
      score += 0.40;
    } else if (h > 90 && h <= 120) {
      // Yellow-green fringe — dry/sandy soil can appear here
      score += 0.15;
    } else if (h > 300) {
      // Reddish-purple — red clay soils
      score += 0.20;
    }
    // Anything 120–300° (green/blue/purple) gets 0 hue points

    // ── Warm channel ordering ─────────────────────────────────────────
    // R ≥ G is the strongest single indicator of a warm/earthy surface
    if (r >= g && g >= b)       score += 0.30; // classic brown: R≥G≥B
    else if (r >= g)            score += 0.18; // warm but not ordered
    else if (r >= b && g >= b)  score += 0.08; // R,G both above blue

    // ── Saturation — flash-tolerant ───────────────────────────────────
    // Flash washes out colour → low S is normal, don't penalise it
    if (s >= 0.08 && s <= 0.75) score += 0.20; // normal earthy range
    else if (s < 0.08)          score += 0.12; // flash-desaturated — still OK
    // High saturation (>0.75) unlikely for soil → 0 points

    // ── Value — flash-tolerant ────────────────────────────────────────
    // Flash brightens → high V is expected, no penalty
    // Just reward "not pitch black"
    if (maxC >= 0.12) score += 0.10;

    return score.clamp(0.0, 1.0);
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Manual torch toggle (no auto-flash ever)
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _toggleTorch() async {
    if (_ctrl == null || !_camReady) return;
    final next = !_torchOn;
    try {
      await _ctrl!.setFlashMode(next ? FlashMode.torch : FlashMode.off);
      setState(() => _torchOn = next);
    } catch (_) {}
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Capture (gated by soil detection)
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _capture() async {
    if (_ctrl == null || !_camReady || _isCapturing || _isAnalyzing) return;
    if (_detectState != _DetectState.soilFound) {
      _showValidationWarning();
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _isCapturing = true);

    // Pause stream while capturing
    try { await _ctrl!.stopImageStream(); } catch (_) {}

    try {
      // Turn off torch before capture so flash doesn't wash out
      if (_torchOn) await _ctrl!.setFlashMode(FlashMode.off);
      final xfile = await _ctrl!.takePicture();
      // Restore torch if it was on
      if (_torchOn) await _ctrl!.setFlashMode(FlashMode.torch);
      setState(() { _isCapturing = false; _isAnalyzing = true; });
      await _analyzeImage(File(xfile.path));
    } catch (e) {
      setState(() { _isCapturing = false; });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Capture failed: $e'),
          backgroundColor: Colors.red[700],
        ));
      }
      // Restart stream
      try { _startImageStream(); } catch (_) {}
    }
  }

  void _showValidationWarning() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Row(children: [
        Icon(Icons.warning_amber_rounded, color: Colors.white, size: 18),
        SizedBox(width: 10),
        Expanded(child: Text('Aim camera at soil to capture')),
      ]),
      backgroundColor: const Color(0xFFE65100),
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Gallery fallback
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _pickFromGallery() async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(
          source: ImageSource.gallery, imageQuality: 85, maxWidth: 1200);
      if (picked != null && mounted) {
        setState(() => _isAnalyzing = true);
        await _analyzeImage(File(picked.path));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Gallery error: $e'),
          backgroundColor: Colors.red[700],
        ));
      }
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Analyse
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _analyzeImage(File file) async {
    await Future.delayed(const Duration(milliseconds: 2000));
    if (!mounted) return;

    final rng = math.Random();
    const soilTypes = [
      'Clay Loam', 'Sandy Soil', 'Silty Clay', 'Loamy Soil', 'Peaty Soil'
    ];
    const levels = ['Low', 'Medium', 'High'];
    final n = levels[rng.nextInt(3)];
    final p = levels[rng.nextInt(3)];
    final k = levels[rng.nextInt(3)];
    int s = 0;
    for (final v in [n, p, k]) {
      if (v == 'High') s += 33;
      else if (v == 'Medium') s += 20;
      else s += 7;
    }
    final score = s.clamp(0, 100).toDouble();
    final ph = 5.5 + rng.nextDouble() * 2.5;

    final result = SoilResult(
      soilType: soilTypes[rng.nextInt(soilTypes.length)],
      date: DateTime.now(),
      overallScore: score,
      status: score >= 70
          ? 'Good Nutrient Level'
          : score >= 45
              ? 'Moderate Nutrient'
              : score >= 25
                  ? 'Low Nutrient'
                  : 'Critical Low Nutrient',
      nitrogenLevel: n,
      phosphorusLevel: p,
      potassiumLevel: k,
      ph: double.parse(ph.toStringAsFixed(1)),
      imagePath: file.path,
    );

    if (!mounted) return;
    setState(() => _isAnalyzing = false);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => CameraResultScreen(result: result)),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Build
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final size   = MediaQuery.of(context).size;
    final topPad = MediaQuery.of(context).padding.top;
    final botPad = MediaQuery.of(context).padding.bottom;

    const boxTopRatio = 0.17;
    const boxHRatio   = 0.54;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(children: [

          // ── Live preview ─────────────────────────────────────────────
          if (_camReady && _ctrl != null)
            Positioned.fill(
              child: ClipRect(
                child: OverflowBox(
                  alignment: Alignment.center,
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: size.width,
                      height: size.width * _ctrl!.value.aspectRatio,
                      child: CameraPreview(_ctrl!),
                    ),
                  ),
                ),
              ),
            ),

          // ── Spinner while init ────────────────────────────────────────
          if (!_camReady && !_camError)
            const Center(child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(color: Color(0xFF7DB560)),
                SizedBox(height: 16),
                Text('Starting camera…',
                    style: TextStyle(color: Colors.white54, fontSize: 14)),
              ],
            )),

          if (_camError) _buildErrorView(),

          // ── Vignette ─────────────────────────────────────────────────
          if (_camReady)
            Positioned.fill(child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center, radius: 1.1,
                  colors: [Colors.transparent, Colors.black54],
                ),
              ),
            )),

          // ── Scan line ─────────────────────────────────────────────────
          if (_camReady && !_isAnalyzing)
            AnimatedBuilder(
              animation: _scanLineAnim,
              builder: (_, __) {
                final top = size.height * boxTopRatio;
                final boxH = size.height * boxHRatio;
                return Positioned(
                  top: top + _scanLineAnim.value * boxH,
                  left: size.width * 0.07,
                  right: size.width * 0.07,
                  child: Container(
                    height: 2,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [
                        Colors.transparent,
                        _stateColor.withOpacity(0.85),
                        Colors.transparent,
                      ]),
                      boxShadow: [
                        BoxShadow(
                          color: _stateColor.withOpacity(0.45),
                          blurRadius: 8,
                        )
                      ],
                    ),
                  ),
                );
              },
            ),

          // ── Corner brackets ───────────────────────────────────────────
          if (_camReady)
            Positioned(
              top: size.height * boxTopRatio,
              left: size.width * 0.06,
              right: size.width * 0.06,
              height: size.height * boxHRatio,
              child: AnimatedBuilder(
                animation: _cornerAnim,
                builder: (_, __) => CustomPaint(
                  painter: _CornerBracketPainter(
                    color: _stateColor,
                    progress: _cornerAnim.value,
                  ),
                ),
              ),
            ),

          // ── Status badge ──────────────────────────────────────────────
          if (_camReady)
            Positioned(
              top: size.height * boxTopRatio - 44,
              left: 0, right: 0,
              child: Center(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 280),
                  child: Container(
                    key: ValueKey(_detectState),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: _stateColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: _stateColor.withOpacity(0.55), width: 1.2),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      AnimatedBuilder(
                        animation: _pulseCtrl,
                        builder: (_, __) => Container(
                          width: 7, height: 7,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _stateColor.withOpacity(
                                0.5 + 0.5 * _pulseCtrl.value),
                          ),
                        ),
                      ),
                      const SizedBox(width: 7),
                      Text(_stateLabel,
                          style: TextStyle(
                            color: _stateColor,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.3,
                          )),
                    ]),
                  ),
                ),
              ),
            ),

          // ── Soil confidence bar ───────────────────────────────────────
          if (_camReady && !_isAnalyzing)
            Positioned(
              bottom: botPad + 126,
              left: size.width * 0.06,
              right: size.width * 0.06,
              child: Column(children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Soil Match',
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.5),
                            fontSize: 11)),
                    Text('${(_soilConfidence * 100).toInt()}%',
                        style: TextStyle(
                            color: _stateColor,
                            fontSize: 11,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 5),
                ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: LinearProgressIndicator(
                    value: _soilConfidence,
                    minHeight: 5,
                    backgroundColor: Colors.white12,
                    valueColor: AlwaysStoppedAnimation(_stateColor),
                  ),
                ),
              ]),
            ),

          // ── Analysing overlay ─────────────────────────────────────────
          if (_isAnalyzing)
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.75),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 56, height: 56,
                      child: CircularProgressIndicator(
                          strokeWidth: 3, color: Color(0xFF7DB560)),
                    ),
                    const SizedBox(height: 20),
                    const Text('Analysing soil sample…',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    Text('Reading N · P · K · pH values',
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.5),
                            fontSize: 13)),
                  ],
                ),
              ),
            ),

          // ── Top bar (close only + HD badge) ──────────────────────────
          Positioned(
            top: 0, left: 0, right: 0,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.black87, Colors.transparent],
                ),
              ),
              padding: EdgeInsets.only(
                  top: topPad + 6, left: 8, right: 16, bottom: 16),
              child: Row(children: [
                // Close
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 40, height: 40,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      color: Colors.white12,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.close,
                        color: Colors.white, size: 20),
                  ),
                ),
                const Spacer(),
                // HD badge
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white12,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text('HD',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold)),
                ),
              ]),
            ),
          ),

          // ── Hint text ─────────────────────────────────────────────────
          if (_camReady && !_isAnalyzing)
            Positioned(
              bottom: botPad + 104,
              left: 0, right: 0,
              child: Center(
                child: Text(
                  _detectState == _DetectState.soilFound
                      ? 'Ready — tap shutter to capture'
                      : 'Point camera at soil sample',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.55), fontSize: 12),
                ),
              ),
            ),

          // ── Bottom bar ─────────────────────────────────────────────────
          // Layout: [Gallery]  [Shutter]  [Flash]
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black, Colors.transparent],
                ),
              ),
              padding: EdgeInsets.only(
                  bottom: botPad + 20,
                  top: 20,
                  left: 28,
                  right: 28),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [

                  // ── Gallery ──────────────────────────────────────────
                  _BottomActionBtn(
                    icon: Icons.photo_library_outlined,
                    label: 'Gallery',
                    onTap: _isAnalyzing ? null : _pickFromGallery,
                  ),

                  // ── Shutter ───────────────────────────────────────────
                  GestureDetector(
                    onTap: _isCapturing || _isAnalyzing ? null : _capture,
                    child: AnimatedBuilder(
                      animation: _pulseCtrl,
                      builder: (_, __) {
                        final canShoot =
                            _detectState == _DetectState.soilFound &&
                            !_isCapturing &&
                            !_isAnalyzing;
                        return Container(
                          width: 74, height: 74,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: canShoot
                                ? Color.lerp(
                                    const Color(0xFFFFD600),
                                    const Color(0xFFFFAA00),
                                    _pulseCtrl.value)!
                                : Colors.white24,
                            boxShadow: canShoot
                                ? [
                                    BoxShadow(
                                      color: const Color(0xFFFFD600)
                                          .withOpacity(
                                              0.35 + 0.25 * _pulseCtrl.value),
                                      blurRadius: 24,
                                      spreadRadius: 4,
                                    )
                                  ]
                                : [],
                          ),
                          child: Icon(
                            _isCapturing
                                ? Icons.hourglass_top_rounded
                                : Icons.camera_alt_rounded,
                            color: canShoot
                                ? Colors.black87
                                : Colors.white38,
                            size: 30,
                          ),
                        );
                      },
                    ),
                  ),

                  // ── Flash (manual torch) ──────────────────────────────
                  _BottomActionBtn(
                    icon: _torchOn
                        ? Icons.flashlight_on_rounded
                        : Icons.flashlight_off_rounded,
                    label: _torchOn ? 'Flash On' : 'Flash',
                    active: _torchOn,
                    onTap: _camReady && !_isAnalyzing ? _toggleTorch : null,
                  ),
                ],
              ),
            ),
          ),

        ]),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  Widget _buildErrorView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 80, height: 80,
            decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.1),
                shape: BoxShape.circle),
            child: const Icon(Icons.no_photography_outlined,
                size: 44, color: Colors.red),
          ),
          const SizedBox(height: 20),
          const Text('Camera Unavailable',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Text(_errorMsg,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey[400], fontSize: 13)),
          const SizedBox(height: 28),
          ElevatedButton.icon(
            onPressed: _initCamera,
            icon: const Icon(Icons.refresh),
            label: const Text('Retry'),
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4E7A3E),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20))),
          ),
          const SizedBox(height: 12),
          TextButton.icon(
            onPressed: _pickFromGallery,
            icon: const Icon(Icons.photo_library_outlined,
                color: Colors.grey),
            label: const Text('Use Gallery',
                style: TextStyle(color: Colors.grey)),
          ),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Corner bracket painter
// ─────────────────────────────────────────────────────────────────────────────
class _CornerBracketPainter extends CustomPainter {
  final Color color;
  final double progress;
  const _CornerBracketPainter({required this.color, required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color.lerp(Colors.white38, color, progress)!
      ..strokeWidth = 3.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()
        ..color = Colors.white.withOpacity(0.06)
        ..strokeWidth = 1
        ..style = PaintingStyle.stroke,
    );

    const arm = 32.0;
    _corner(canvas, paint, Offset.zero, arm, 1, 1);
    _corner(canvas, paint, Offset(size.width, 0), arm, -1, 1);
    _corner(canvas, paint, Offset(0, size.height), arm, 1, -1);
    _corner(canvas, paint, Offset(size.width, size.height), arm, -1, -1);
  }

  void _corner(Canvas c, Paint p, Offset o, double len, int dx, int dy) {
    final path = Path()
      ..moveTo(o.dx + dx * len, o.dy)
      ..lineTo(o.dx, o.dy)
      ..lineTo(o.dx, o.dy + dy * len);
    c.drawPath(path, p);
  }

  @override
  bool shouldRepaint(_CornerBracketPainter old) =>
      old.color != color || old.progress != progress;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Bottom action button
// ─────────────────────────────────────────────────────────────────────────────
class _BottomActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool active;
  const _BottomActionBtn({
    required this.icon,
    required this.label,
    this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: SizedBox(
          width: 62,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                color: active
                    ? const Color(0xFFFFD600).withOpacity(0.2)
                    : Colors.white12,
                borderRadius: BorderRadius.circular(12),
                border: active
                    ? Border.all(
                        color: const Color(0xFFFFD600).withOpacity(0.6),
                        width: 1.2)
                    : null,
              ),
              child: Icon(icon,
                  color: active
                      ? const Color(0xFFFFD600)
                      : Colors.white70,
                  size: 22),
            ),
            const SizedBox(height: 5),
            Text(label,
                style: TextStyle(
                    color: active
                        ? const Color(0xFFFFD600)
                        : Colors.white54,
                    fontSize: 10,
                    fontWeight: FontWeight.w500)),
          ]),
        ),
      );
}
