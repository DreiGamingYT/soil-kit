import 'package:flutter/material.dart';
import '../models/soil_data_service.dart';
import 'settings_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _svc = SoilDataService.instance;
  String _name = 'Username';
  String _email = 'user@email.com';
  String _location = 'Lunita Park';

  void _editProfile() {
    final nameCtrl = TextEditingController(text: _name);
    final emailCtrl = TextEditingController(text: _email);
    final locCtrl = TextEditingController(text: _location);

    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
            left: 16, right: 16, top: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20),
        child: Column(mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start, children: [
              Center(child: Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)))),
              const Text('Edit Profile', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              _EditField(controller: nameCtrl, label: 'Full Name', icon: Icons.person_outline),
              const SizedBox(height: 10),
              _EditField(controller: emailCtrl, label: 'Email', icon: Icons.email_outlined),
              const SizedBox(height: 10),
              _EditField(controller: locCtrl, label: 'Location', icon: Icons.location_on_outlined),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(child: OutlinedButton(
                    onPressed: () => Navigator.pop(context), child: const Text('Cancel'))),
                const SizedBox(width: 10),
                Expanded(child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4E7A3E)),
                    onPressed: () {
                      setState(() {
                        if (nameCtrl.text.trim().isNotEmpty) _name = nameCtrl.text.trim();
                        if (emailCtrl.text.trim().isNotEmpty) _email = emailCtrl.text.trim();
                        if (locCtrl.text.trim().isNotEmpty) _location = locCtrl.text.trim();
                      });
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                          content: Text('Profile updated!'),
                          backgroundColor: Color(0xFF4E7A3E)));
                    },
                    child: const Text('Save', style: TextStyle(color: Colors.white)))),
              ]),
            ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          const SizedBox(height: 8),

          // Avatar with edit button
          Stack(children: [
            Container(
              width: 90, height: 90,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF4E7A3E).withOpacity(0.12),
                  border: Border.all(color: const Color(0xFF4E7A3E), width: 2.5)),
              child: const Icon(Icons.person, size: 52, color: Color(0xFF4E7A3E)),
            ),
            Positioned(bottom: 0, right: 0,
                child: GestureDetector(
                    onTap: _editProfile,
                    child: Container(width: 28, height: 28,
                        decoration: const BoxDecoration(
                            shape: BoxShape.circle, color: Color(0xFF4E7A3E)),
                        child: const Icon(Icons.edit, size: 14, color: Colors.white)))),
          ]),

          const SizedBox(height: 12),
          Text(_name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 2),
          Text(_email, style: const TextStyle(color: Colors.grey, fontSize: 13)),
          const SizedBox(height: 4),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.location_on_outlined, size: 14, color: Colors.grey),
            const SizedBox(width: 3),
            Text(_location, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ]),
          const SizedBox(height: 24),

          // Live stats
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _StatCard(value: '${_svc.resultsCount}', label: 'Analyses'),
            _StatCard(value: '${_svc.notesCount}', label: 'Notes'),
            _StatCard(value: '1', label: 'Fields'),
          ]),
          const SizedBox(height: 28),

          // Menu tiles — cleaned up
          _ProfileTile(icon: Icons.edit_outlined, label: 'Edit Profile', onTap: _editProfile),
          _ProfileTile(
              icon: Icons.settings_outlined, label: 'Settings',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
          _ProfileTile(
              icon: Icons.notifications_outlined, label: 'Notification Preferences',
              subtitle: 'Manage in Settings',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
          _ProfileTile(
              icon: Icons.help_outline, label: 'About the App',
              subtitle: 'Version 1.0.0 · Developers',
              onTap: () => _showAbout(context)),
        ]),
      ),
    );
  }

  void _showAbout(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── Fixed header ─────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
              child: Column(children: [
                Container(
                    width: 70, height: 70,
                    decoration: BoxDecoration(
                        color: const Color(0xFF4E7A3E).withOpacity(0.1),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.eco, size: 38, color: Color(0xFF4E7A3E))),
                const SizedBox(height: 14),
                const Text('SoilMate',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const Text('Version 1.0.0',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                const SizedBox(height: 16),
                const Divider(),
              ]),
            ),
            // ── Scrollable body ──────────────────────────────────────
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 12),
                    const Center(
                      child: Text('GTECH SOLUTION COMPANY',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold,
                              letterSpacing: 1.5, color: Colors.grey)),
                    ),
                    const SizedBox(height: 12),
                    _DevRow(name: 'CEO', value: 'Bolatin, Jane Alexa'),
                    _DevRow(name: 'Product/Marketing Lead', value: 'Garde, Denise Kenchien'),
                    _DevRow(name: 'Content Specialist', value: 'Dayna, John Mark'),
                    _DevRow(name: 'Technical Lead', value: 'Velasco, Jonathan'),
                    _DevRow(name: 'UI/UX Designer', value: 'Suagen, Allysa Jasmin'),
                    _DevRow(name: 'Software Developer', value: 'De Guzman, Maenalyn'),
                    _DevRow(name: 'Finance Manager', value: 'Ilagor, Paul John'),
                    _DevRow(name: 'Documentation Specialist', value: 'Malabiga, Yui Rave'),
                    _DevRow(name: 'Records Coordinator', value: 'Siarot, Reydin'),
                    _DevRow(name: 'Research & Feature Lead', value: 'Anza Jr., Jonathan'),
                    _DevRow(name: 'Quality Assurance', value: 'Delos Reyes'),
                    const SizedBox(height: 12),
                    const Divider(),
                    const SizedBox(height: 8),
                    Center(
                      child: Text('© 2026 Soil App Team. All rights reserved.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey[500], fontSize: 11)),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
            // ── Fixed footer ─────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 20),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4E7A3E),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    child: const Text('Close')),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EditField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  const _EditField({required this.controller, required this.label, required this.icon});
  @override
  Widget build(BuildContext context) => TextField(
      controller: controller,
      decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: const Color(0xFF4E7A3E)),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))));
}

class _StatCard extends StatelessWidget {
  final String value, label;
  const _StatCard({required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
    decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade200),
        borderRadius: BorderRadius.circular(12)),
    child: Column(children: [
      Text(value, style: const TextStyle(
          fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF4E7A3E))),
      Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
    ]),
  );
}

class _ProfileTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? subtitle;
  final Color? color;
  final VoidCallback onTap;
  const _ProfileTile({required this.icon, required this.label,
    required this.onTap, this.color, this.subtitle});
  @override
  Widget build(BuildContext context) {
    final c = color ?? Colors.black87;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      leading: Icon(icon, color: c),
      title: Text(label, style: TextStyle(color: c, fontSize: 14, fontWeight: FontWeight.w500)),
      subtitle: subtitle != null
          ? Text(subtitle!, style: const TextStyle(fontSize: 12, color: Colors.grey))
          : null,
      trailing: Icon(Icons.chevron_right, color: Colors.grey[300]),
      onTap: onTap,
    );
  }
}

class _DevRow extends StatelessWidget {
  final String name, value;
  const _DevRow({required this.name, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      SizedBox(width: 120, child: Text(name,
          style: const TextStyle(fontSize: 12, color: Colors.grey))),
      Expanded(child: Text(value,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
    ]),
  );
}