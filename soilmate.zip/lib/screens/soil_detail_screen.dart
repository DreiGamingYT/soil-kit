import 'package:flutter/material.dart';

class SoilDetailScreen extends StatelessWidget {
  final Map<String, dynamic> soil;

  const SoilDetailScreen({super.key, required this.soil});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(soil['name'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF4E7A3E),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero color block
            Container(
              width: double.infinity,
              height: 100,
              decoration: BoxDecoration(
                color: Color(soil['color'] as int),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Center(
                child: Text(
                  soil['name'] as String,
                  style: TextStyle(
                    color: (soil['color'] as int) == 0xFFECEFF1
                        ? Colors.black54
                        : Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    shadows: const [Shadow(blurRadius: 4, color: Colors.black26)],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            _DetailCard(
              title: 'Description',
              content: soil['fullDesc'] as String,
            ),
            _DetailCard(
              title: 'Best Crops',
              content: soil['crops'] as String,
            ),
            _DetailCard(
              title: 'Typical pH Range',
              content: soil['ph'] as String,
            ),
            _DetailCard(
              title: 'Drainage',
              content: soil['drainage'] as String,
            ),
            _DetailCard(
              title: 'Improvement Tips',
              content: soil['tips'] as String,
            ),

            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.camera_alt_outlined),
                label: const Text('Test This Soil'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4E7A3E),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _DetailCard extends StatelessWidget {
  final String title;
  final String content;

  const _DetailCard({required this.title, required this.content});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade200),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: Color(0xFF4E7A3E),
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            content,
            style: const TextStyle(fontSize: 14, color: Colors.black87, height: 1.5),
          ),
        ],
      ),
    );
  }
}
