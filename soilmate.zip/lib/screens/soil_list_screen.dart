import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';
import 'soil_detail_screen.dart';

class SoilListScreen extends StatefulWidget {
  const SoilListScreen({super.key});
  @override
  State<SoilListScreen> createState() => _SoilListScreenState();
}

class _SoilListScreenState extends State<SoilListScreen> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _query = '';

  static final List<Map<String, dynamic>> _soils = [
    {
      'name': 'Clay Soil', 'desc': 'High in nutrients, poor drainage',
      'color': 0xFF8D6E63,
      'fullDesc': 'Clay soil is made up of very fine particles that pack together tightly. It retains moisture and nutrients well but can become waterlogged and is difficult to work with when wet or dry.',
      'crops': 'Wheat, cabbage, lettuce, broccoli, Brussels sprouts',
      'ph': '5.5 – 7.0', 'drainage': 'Poor – prone to waterlogging',
      'tips': 'Add organic matter (compost) to improve aeration. Avoid working the soil when wet. Consider raised beds for better drainage.',
    },
    {
      'name': 'Sandy Soil', 'desc': 'Good drainage, low nutrients',
      'color': 0xFFD7CCC8,
      'fullDesc': 'Sandy soil has large particles with lots of space between them. Water and nutrients drain through it quickly, making it easy to work but challenging to keep fertile.',
      'crops': 'Root vegetables (carrots, radishes), strawberries, potatoes',
      'ph': '5.5 – 7.0', 'drainage': 'Excellent – drains very fast',
      'tips': 'Add organic matter frequently to improve nutrient retention. Mulch heavily to reduce water evaporation. Use slow-release fertilizers.',
    },
    {
      'name': 'Silty Soil', 'desc': 'Fertile, holds moisture well',
      'color': 0xFFA1887F,
      'fullDesc': 'Silty soil has medium-sized particles that feel smooth and soapy. It is fertile, retains moisture well, and is easy to cultivate, but can compact easily.',
      'crops': 'Most vegetables and fruits, especially moisture-loving crops',
      'ph': '6.0 – 7.0', 'drainage': 'Moderate – can become compacted',
      'tips': 'Avoid heavy machinery to prevent compaction. Add compost to maintain structure. Ideal for most crops with minimal amendment.',
    },
    {
      'name': 'Loamy Soil', 'desc': 'Ideal balance of sand, silt, clay',
      'color': 0xFF795548,
      'fullDesc': 'Loamy soil is often considered the ideal soil type. It has a balanced mix of sand, silt, and clay, providing good drainage while also retaining enough moisture and nutrients.',
      'crops': 'Almost all crops — vegetables, fruits, grains, and flowers',
      'ph': '6.0 – 7.0', 'drainage': 'Good – well-balanced',
      'tips': 'Maintain with regular compost additions. Loamy soil is very easy to manage and needs minimal improvement for most crops.',
    },
    {
      'name': 'Peaty Soil', 'desc': 'High organic matter, acidic',
      'color': 0xFF4E342E,
      'fullDesc': 'Peaty soil is dark, rich in organic matter, and has a spongy texture. It retains large amounts of water and is naturally acidic.',
      'crops': 'Blueberries, cranberries, heathers, root crops',
      'ph': '3.5 – 6.0 (acidic)', 'drainage': 'Poor – holds large amounts of water',
      'tips': 'Lime can raise pH for more crop options. Ensure drainage ditches are in place. Excellent for acid-loving plants without amendment.',
    },
    {
      'name': 'Chalky Soil', 'desc': 'Alkaline, free-draining',
      'color': 0xFFECEFF1,
      'fullDesc': 'Chalky soil is stony and free-draining with a high pH due to calcium carbonate content. It can cause nutrient deficiencies, especially iron and manganese.',
      'crops': 'Spinach, beets, sweet corn, cabbage, asparagus',
      'ph': '7.5 – 8.5 (alkaline)', 'drainage': 'Very good – may dry out quickly',
      'tips': 'Add plenty of organic matter and use acidifying fertilizers. Mulch heavily to retain moisture. Choose chalk-tolerant crops.',
    },
  ];

  List<Map<String, dynamic>> get _filtered => _soils
    .where((s) => s['name'].toString().toLowerCase().contains(_query.toLowerCase()))
    .toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Soil List', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white, elevation: 0, foregroundColor: Colors.black, centerTitle: true,
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          child: TextField(
            controller: _searchCtrl,
            onChanged: (v) => setState(() => _query = v),
            decoration: InputDecoration(
              hintText: 'Search soil types...',
              prefixIcon: const Icon(Icons.search, color: Colors.grey),
              suffixIcon: _query.isNotEmpty
                ? IconButton(icon: const Icon(Icons.close, size: 18, color: Colors.grey),
                    onPressed: () => setState(() { _query = ''; _searchCtrl.clear(); }))
                : null,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.shade300)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.shade300)),
              filled: true, fillColor: Colors.grey[50],
              contentPadding: const EdgeInsets.symmetric(vertical: 10)),
          ),
        ),
        Expanded(child: _filtered.isEmpty
          ? Center(child: Text('No soils found for "$_query"', style: const TextStyle(color: Colors.grey)))
          : ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _filtered.length,
              itemBuilder: (context, i) {
                final soil = _filtered[i];
                final isLight = (soil['color'] as int) == 0xFFECEFF1 || (soil['color'] as int) == 0xFFD7CCC8;
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                  elevation: 0,
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    leading: Container(
                      width: 52, height: 52,
                      decoration: BoxDecoration(color: Color(soil['color'] as int), borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey.shade200)),
                      child: Icon(Icons.landscape, color: isLight ? Colors.brown[400] : Colors.white.withOpacity(0.5), size: 22),
                    ),
                    title: Text(soil['name'] as String, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                    subtitle: Text(soil['desc'] as String, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                    trailing: const Icon(Icons.chevron_right, color: Colors.grey),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SoilDetailScreen(soil: soil))),
                  ),
                );
              })),
      ]),
      bottomNavigationBar: AppBottomNav(selectedIndex: 0, onTap: (_) => Navigator.pop(context)),
    );
  }
}
