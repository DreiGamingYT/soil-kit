import 'package:flutter/material.dart';

class HelpGuideScreen extends StatelessWidget {
  const HelpGuideScreen({super.key});

  static const _steps = [
    {
      'icon': Icons.science_outlined,
      'title': 'Step 1: Prepare the Soil Sample',
      'desc':
          'Collect about 1 tablespoon of soil from your field. Remove stones and large debris. Mix the soil with distilled water in the provided container until it becomes a thin, muddy solution.',
      'tip': 'Tip: Collect soil from 3–5 different spots in your field and mix them together for a more representative sample.',
    },
    {
      'icon': Icons.colorize_outlined,
      'title': 'Step 2: Apply the Reagents',
      'desc':
          'Using the dropper provided, add the correct reagent for each test:\n• Red cap → Nitrogen (N) test\n• Blue cap → Phosphorus (P) test\n• Yellow cap → Potassium (K) test\n• White cap → pH test\n\nWait 2–3 minutes for the color reaction to fully develop.',
      'tip': 'Tip: Do one nutrient at a time to avoid cross-contamination between test wells.',
    },
    {
      'icon': Icons.camera_alt_outlined,
      'title': 'Step 3: Capture the Color',
      'desc':
          'Tap the camera button at the bottom of the Home screen. Position your phone directly above the test strip in good, even lighting. Avoid shadows and reflections. Tap the image area to capture the photo.',
      'tip': 'Tip: Natural daylight gives the most accurate color reading. Avoid fluorescent or tinted lights.',
    },
    {
      'icon': Icons.analytics_outlined,
      'title': 'Step 4: Analyze the Result',
      'desc':
          'Once the photo is captured, tap "Analyze Soil." The app will read the RGB color values from the image and compare them to the reference color chart to estimate nutrient levels and pH.',
      'tip': 'Tip: If the result seems off, retake the photo in better lighting and try again.',
    },
    {
      'icon': Icons.save_outlined,
      'title': 'Step 5: Save and Record',
      'desc':
          'Review the result showing your Overall Score, Nitrogen, Phosphorus, Potassium levels, and pH value. Tap "Save" to store the result. It will appear in your History screen for future reference.',
      'tip': 'Tip: Add a note in the Notes screen to record the location, crop type, or any observations.',
    },
    {
      'icon': Icons.compare_arrows_outlined,
      'title': 'Step 6: Compare Over Time',
      'desc':
          'Visit the History screen to compare past analyses. Track nutrient trends across multiple tests to understand how your soil health changes with weather, crops, and fertilization.',
      'tip': 'Tip: Test your soil at the beginning and end of each growing season for best insights.',
    },
  ];

  static const _colorGuide = [
    {'nutrient': 'Nitrogen', 'low': 'Light Yellow', 'medium': 'Orange', 'high': 'Dark Red', 'color': 0xFFE53935},
    {'nutrient': 'Phosphorus', 'low': 'Pale Blue', 'medium': 'Blue', 'high': 'Dark Blue', 'color': 0xFF1565C0},
    {'nutrient': 'Potassium', 'low': 'Light Green', 'medium': 'Green', 'high': 'Dark Green', 'color': 0xFF2E7D32},
    {'nutrient': 'pH', 'low': 'Red (Acidic)', 'medium': 'Green (Neutral)', 'high': 'Purple (Alkaline)', 'color': 0xFF6A1B9A},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Help & Guide', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF4E7A3E),
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Banner
            Container(
              width: double.infinity,
              color: const Color(0xFF4E7A3E),
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
              child: const Text(
                'How to Use the Soil Test Kit',
                style: TextStyle(color: Colors.white70, fontSize: 14),
              ),
            ),

            // Steps
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ..._steps.map((step) => _StepCard(step: step)),

                  const SizedBox(height: 8),
                  const Text(
                    'Quick Color Reference',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),

                  // Color reference table
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade200),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        // Header
                        Container(
                          decoration: const BoxDecoration(
                            color: Color(0xFF4E7A3E),
                            borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          child: const Row(
                            children: [
                              Expanded(flex: 2, child: Text('Nutrient', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13))),
                              Expanded(flex: 2, child: Text('Low', style: TextStyle(color: Colors.white, fontSize: 12))),
                              Expanded(flex: 2, child: Text('Medium', style: TextStyle(color: Colors.white, fontSize: 12))),
                              Expanded(flex: 2, child: Text('High', style: TextStyle(color: Colors.white, fontSize: 12))),
                            ],
                          ),
                        ),
                        ..._colorGuide.asMap().entries.map((e) {
                          final isLast = e.key == _colorGuide.length - 1;
                          final item = e.value;
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              border: isLast ? null : Border(bottom: BorderSide(color: Colors.grey.shade200)),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Row(
                                    children: [
                                      Container(width: 10, height: 10, decoration: BoxDecoration(color: Color(item['color'] as int), shape: BoxShape.circle)),
                                      const SizedBox(width: 6),
                                      Text(item['nutrient'] as String, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                                    ],
                                  ),
                                ),
                                Expanded(flex: 2, child: Text(item['low'] as String, style: const TextStyle(fontSize: 11, color: Colors.black54))),
                                Expanded(flex: 2, child: Text(item['medium'] as String, style: const TextStyle(fontSize: 11, color: Colors.black54))),
                                Expanded(flex: 2, child: Text(item['high'] as String, style: const TextStyle(fontSize: 11, color: Colors.black54))),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StepCard extends StatelessWidget {
  final Map<String, dynamic> step;
  const _StepCard({required this.step});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF4E7A3E).withOpacity(0.04),
        border: Border.all(color: const Color(0xFF4E7A3E).withOpacity(0.2)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(step['icon'] as IconData, color: const Color(0xFF4E7A3E), size: 22),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  step['title'] as String,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            step['desc'] as String,
            style: const TextStyle(fontSize: 13, color: Colors.black54, height: 1.5),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.amber.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.lightbulb_outline, color: Colors.amber, size: 16),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    step['tip'] as String,
                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
