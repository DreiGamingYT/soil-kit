import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';

class ColorChartScreen extends StatelessWidget {
  const ColorChartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Color Chart', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Divider(),
            const SizedBox(height: 12),

            // pH Scale section
            _SectionLabel(label: 'pH Scale'),
            const SizedBox(height: 12),
            _PhScaleChart(),
            const SizedBox(height: 24),

            // Nitrogen Level
            _SectionLabel(label: 'Nitrogen Level'),
            const SizedBox(height: 12),
            _NutrientChart(
              title: 'Nitrate nitrogen (mg/kg)',
              segments: const [
                _Segment('Low',     Color(0xFFE53935), 0, 10),
                _Segment('Caution', Color(0xFFFDD835), 10, 20),
                _Segment('Medium', Color(0xFFFF6D00), 20, 40),
                _Segment('Caution', Color(0xFFFDD835), 40, 50),
                _Segment('High',  Color(0xFF43A047), 50, 60),
              ],
              maxValue: 60,
            ),
            const SizedBox(height: 24),

            // Phosphorus Level
            _SectionLabel(label: 'Phosphorus Level'),
            const SizedBox(height: 12),
            _NutrientChart(
              title: 'Phosphorus (mg/kg)',
              segments: const [
                _Segment('Low',     Color(0xFFE53935), 0, 10),
                _Segment('Caution', Color(0xFFFDD835), 10, 20),
                _Segment('Medium', Color(0xFFFF6D00), 20, 40),
                _Segment('Caution', Color(0xFFFDD835), 40, 50),
                _Segment('High',  Color(0xFF43A047), 50, 60),
              ],
              maxValue: 70,
            ),
            const SizedBox(height: 24),

            // Potassium Level
            _SectionLabel(label: 'Potassium Level'),
            const SizedBox(height: 12),
            _NutrientChart(
              title: 'Potassium (mg/kg)',
              segments: const [
                _Segment('Low',     Color(0xFFE53935), 0, 10),
                _Segment('Caution', Color(0xFFFDD835), 10, 20),
                _Segment('Medium', Color(0xFFFF6D00), 20, 40),
                _Segment('Caution', Color(0xFFFDD835), 40, 50),
                _Segment('High',  Color(0xFF43A047), 50, 60),
              ],
              maxValue: 300,
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
      bottomNavigationBar: AppBottomNav(
        selectedIndex: 0,
        onTap: (_) => Navigator.pop(context),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
    );
  }
}

class _PhScaleChart extends StatelessWidget {
  final List<Color> phColors = const [
    Color(0xFFE53935), // 0 - red
    Color(0xFFE57C00), // 1 - dark orange
    Color(0xFFFF9800), // 2 - orange
    Color(0xFFFFB300), // 3 - amber
    Color(0xFFFFEA00), // 4 - yellow
    Color(0xFF76FF03), // 5 - lime
    Color(0xFF00E676), // 6 - light green
    Color(0xFF00BCD4), // 7 - cyan (neutral)
    Color(0xFF00ACC1), // 8 - teal
    Color(0xFF0288D1), // 9 - blue
    Color(0xFF1565C0), // 10 - dark blue
    Color(0xFF4527A0), // 11 - indigo
    Color(0xFF6A1B9A), // 12 - purple
    Color(0xFF4A148C), // 13 - deep purple
    Color(0xFF311B92), // 14 - darkest purple
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Numbers row
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(
            15,
                (i) => SizedBox(
              width: 18,
              child: Text(
                '$i',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10),
              ),
            ),
          ),
        ),
        const SizedBox(height: 2),
        // Color bar
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: SizedBox(
            height: 50,
            child: Row(
              children: List.generate(
                15,
                    (i) => Expanded(
                  child: Container(color: phColors[i]),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 6),
        // Labels
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('acidic', style: TextStyle(fontSize: 11, color: Colors.black54)),
            Text('neutral', style: TextStyle(fontSize: 11, color: Colors.black54)),
            Text('alkaline', style: TextStyle(fontSize: 11, color: Colors.black54)),
          ],
        ),
      ],
    );
  }
}

class _Segment {
  final String label;
  final Color color;
  final double start;
  final double end;

  const _Segment(this.label, this.color, this.start, this.end);
}

class _NutrientChart extends StatelessWidget {
  final String title;
  final List<_Segment> segments;
  final double maxValue;

  const _NutrientChart({
    required this.title,
    required this.segments,
    required this.maxValue,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
        const SizedBox(height: 6),
        // Colored bar
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: SizedBox(
            height: 28,
            child: Row(
              children: segments.map((seg) {
                final flex = ((seg.end - seg.start) / maxValue * 100).round();
                return Expanded(
                  flex: flex,
                  child: Container(
                    color: seg.color,
                    alignment: Alignment.center,
                    child: Text(
                      seg.label,
                      style: TextStyle(
                        color: seg.color == const Color(0xFFFDD835)
                            ? Colors.black87
                            : Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
        const SizedBox(height: 4),
        // Scale numbers
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('0', style: const TextStyle(fontSize: 10, color: Colors.black54)),
            ...segments.map(
                  (seg) => Text(
                '${seg.end.toInt()}',
                style: const TextStyle(fontSize: 10, color: Colors.black54),
              ),
            ),
          ],
        ),
      ],
    );
  }
}