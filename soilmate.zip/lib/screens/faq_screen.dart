import 'package:flutter/material.dart';

class FaqScreen extends StatefulWidget {
  const FaqScreen({super.key});

  @override
  State<FaqScreen> createState() => _FaqScreenState();
}

class _FaqScreenState extends State<FaqScreen> {
  final List<Map<String, String>> _faqs = [
    {
      'q': 'What does this app do?',
      'a': 'The Soil Nutrient Color-Test Kit App helps you measure key soil nutrients — Nitrogen (N), Phosphorus (P), Potassium (K), and pH — using simple color reactions captured by your smartphone camera.',
    },
    {
      'q': 'How do I use the camera to test my soil?',
      'a': 'Mix your soil sample with the provided chemical reagents. Once the color reaction occurs, tap the camera button on the home screen, take a photo of the test strip, and tap "Analyze Soil." The app will estimate nutrient concentrations from the RGB color values.',
    },
    {
      'q': 'What do the nutrient levels mean?',
      'a': 'Low means the soil is deficient and needs fertilization. Medium is acceptable but can be improved. High means nutrients are sufficient or possibly excessive. Always match results with recommended ranges for your crop type.',
    },
    {
      'q': 'What is pH and why does it matter?',
      'a': 'pH measures how acidic or alkaline your soil is, on a scale of 0–14. Most plants thrive between pH 6–7 (slightly acidic to neutral). Extreme pH values can prevent plants from absorbing nutrients even if they are present in the soil.',
    },
    {
      'q': 'How accurate is the app?',
      'a': 'The app uses image processing (RGB color analysis) to estimate nutrient levels from your test kit reaction. Accuracy depends on lighting conditions and the quality of the reagent reaction. For critical decisions, cross-check with laboratory tests.',
    },
    {
      'q': 'Can I save and compare results over time?',
      'a': 'Yes! After every analysis, tap "Save" to store the result. You can view all past results in the History screen and track how your soil health changes over time.',
    },
    {
      'q': 'What reagents do I need for the test kit?',
      'a': 'The physical test kit includes reagents for Nitrogen (nitrate), Phosphorus, Potassium, and pH. Each reagent produces a distinct color when mixed with a soil sample dissolved in water.',
    },
    {
      'q': 'Why does my camera result look incorrect?',
      'a': 'Make sure you are in good, even lighting (natural daylight is best). Avoid shadows or reflections on the test strip. Hold the camera steady and ensure the test area fills the frame before capturing.',
    },
  ];

  int? _expanded;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('FAQ', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF4E7A3E),
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: const Color(0xFF4E7A3E),
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            child: const Text(
              'Frequently Asked Questions',
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _faqs.length,
              itemBuilder: (context, i) {
                final isOpen = _expanded == i;
                return GestureDetector(
                  onTap: () => setState(() => _expanded = isOpen ? null : i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                      color: isOpen ? const Color(0xFF4E7A3E).withOpacity(0.05) : Colors.white,
                      border: Border.all(
                        color: isOpen ? const Color(0xFF4E7A3E) : Colors.grey.shade300,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                isOpen ? Icons.remove_circle_outline : Icons.add_circle_outline,
                                color: const Color(0xFF4E7A3E),
                                size: 20,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  _faqs[i]['q']!,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                    color: isOpen ? const Color(0xFF4E7A3E) : Colors.black87,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          if (isOpen) ...[
                            const SizedBox(height: 10),
                            Padding(
                              padding: const EdgeInsets.only(left: 30),
                              child: Text(
                                _faqs[i]['a']!,
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: Colors.black54,
                                  height: 1.5,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
