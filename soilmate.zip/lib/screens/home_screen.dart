import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';
import 'color_chart_screen.dart';
import 'history_screen.dart';
import 'notes_screen.dart';
import 'soil_list_screen.dart';
import 'profile_screen.dart';
import 'faq_screen.dart';
import 'help_guide_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onNavTap;
  const HomeScreen({super.key, required this.selectedIndex, required this.onNavTap});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: selectedIndex == 2 ? const ProfileScreen() : const _HomeBody(),
      bottomNavigationBar: AppBottomNav(selectedIndex: selectedIndex, onTap: onNavTap),
    );
  }
}

class _HomeBody extends StatefulWidget {
  const _HomeBody();
  @override
  State<_HomeBody> createState() => _HomeBodyState();
}

class _HomeBodyState extends State<_HomeBody> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _query = '';

  final List<Map<String, dynamic>> _allItems = [
    {'label': 'Color Chart', 'icon': Icons.palette_outlined, 'screen': 'color_chart'},
    {'label': 'History', 'icon': Icons.history_outlined, 'screen': 'history'},
    {'label': 'Soil List', 'icon': Icons.terrain_outlined, 'screen': 'soil_list'},
    {'label': 'Notes', 'icon': Icons.note_alt_outlined, 'screen': 'notes'},
    {'label': 'FAQ', 'icon': Icons.help_outline, 'screen': 'faq'},
    {'label': 'Help & Guide', 'icon': Icons.menu_book_outlined, 'screen': 'help'},
    {'label': 'Settings', 'icon': Icons.settings_outlined, 'screen': 'settings'},
  ];

  List<Map<String, dynamic>> get _results => _query.isEmpty ? []
    : _allItems.where((i) => i['label'].toString().toLowerCase().contains(_query.toLowerCase())).toList();

  void _navigate(BuildContext context, String screen) {
    Widget? dest;
    switch (screen) {
      case 'color_chart': dest = const ColorChartScreen(); break;
      case 'history': dest = const HistoryScreen(); break;
      case 'soil_list': dest = const SoilListScreen(); break;
      case 'notes': dest = const NotesScreen(); break;
      case 'faq': dest = const FaqScreen(); break;
      case 'help': dest = const HelpGuideScreen(); break;
      case 'settings': dest = const SettingsScreen(); break;
    }
    if (dest != null) {
      setState(() { _query = ''; _searchCtrl.clear(); });
      Navigator.push(context, MaterialPageRoute(builder: (_) => dest!));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // Green header
      Container(
        color: const Color(0xFF4E7A3E),
        padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, left: 16, right: 16, bottom: 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withOpacity(0.6), width: 1.5),
                color: Colors.white.withOpacity(0.15)),
              child: const Icon(Icons.person, color: Colors.white, size: 28)),
            const SizedBox(width: 12),
            const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Hello,', style: TextStyle(color: Colors.white70, fontSize: 13)),
              Text('Username', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
            ]),
            const Spacer(),
            IconButton(
              icon: const Icon(Icons.notifications_outlined, color: Colors.white70),
              onPressed: () {}),
          ]),
          const SizedBox(height: 14),
          Container(
            height: 44,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
            child: TextField(
              controller: _searchCtrl,
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: 'Search features...',
                hintStyle: const TextStyle(color: Colors.grey),
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                suffixIcon: _query.isNotEmpty
                  ? IconButton(icon: const Icon(Icons.close, color: Colors.grey, size: 18),
                    onPressed: () => setState(() { _query = ''; _searchCtrl.clear(); }))
                  : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 12)),
            ),
          ),
        ]),
      ),

      // Search results
      if (_query.isNotEmpty) Container(
        color: Colors.white,
        child: _results.isEmpty
          ? const Padding(padding: EdgeInsets.all(20),
              child: Text('No results found.', style: TextStyle(color: Colors.grey)))
          : Column(children: _results.map((item) => ListTile(
              leading: Icon(item['icon'] as IconData, color: const Color(0xFF4E7A3E)),
              title: Text(item['label'] as String),
              trailing: const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
              onTap: () => _navigate(context, item['screen'] as String),
            )).toList()),
      ),

      if (_query.isEmpty) ...[
        // Quick chips
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              _QuickChip(icon: Icons.help_outline, label: 'FAQ',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FaqScreen()))),
              const SizedBox(width: 8),
              _QuickChip(icon: Icons.menu_book_outlined, label: 'Help & Guide',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpGuideScreen()))),
              const SizedBox(width: 8),
              _QuickChip(icon: Icons.settings_outlined, label: 'Settings',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
            ]),
          ),
        ),
        const SizedBox(height: 4),

        // Main feature grid
        Expanded(child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 1.55,
            children: [
              _GridCard(icon: Icons.palette_outlined, label: 'Color Chart', emoji: '🎨',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ColorChartScreen()))),
              _GridCard(icon: Icons.history_outlined, label: 'History', emoji: '📋',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryScreen()))),
              _GridCard(icon: Icons.terrain_outlined, label: 'Soil List', emoji: '🌍',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SoilListScreen()))),
              _GridCard(icon: Icons.note_alt_outlined, label: 'Notes', emoji: '📝',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotesScreen()))),
            ],
          ),
        )),
      ],
    ]);
  }
}

class _QuickChip extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _QuickChip({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(20), color: Colors.white),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 15, color: const Color(0xFF4E7A3E)),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.black87, fontWeight: FontWeight.w500)),
      ]),
    ),
  );
}

class _GridCard extends StatelessWidget {
  final IconData icon; final String label, emoji; final VoidCallback onTap;
  const _GridCard({required this.icon, required this.label, required this.emoji, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade200),
        borderRadius: BorderRadius.circular(14), color: Colors.white,
        boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 2))]),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(emoji, style: const TextStyle(fontSize: 28)),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.black87)),
      ]),
    ),
  );
}
